from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
import calendar
import re
import random

from qlcc.database import Database
from qlcc.utils import now_iso


@dataclass(slots=True)
class DashboardStats:
    buildings: int
    apartments: int
    residents: int
    open_invoices: int
    unpaid_amount: int


class QueryService:
    def __init__(self, db: Database) -> None:
        self.db = db

    def dashboard_stats(self) -> DashboardStats:
        buildings = self.db.fetch_one("SELECT COUNT(*) AS c FROM buildings")["c"]
        apartments = self.db.fetch_one("SELECT COUNT(*) AS c FROM apartments")["c"]
        residents = self.db.fetch_one("SELECT COUNT(*) AS c FROM residents")["c"]
        open_invoices = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM invoices WHERE status IN ('ISSUED','PARTIALLY_PAID','OVERDUE')"
        )["c"]
        unpaid_amount = self.db.fetch_one(
            """
            SELECT COALESCE(SUM(i.total_amount - COALESCE(p.paid, 0)), 0) AS c
            FROM invoices i
            LEFT JOIN (
                SELECT invoice_id, SUM(amount) AS paid
                FROM payments
                GROUP BY invoice_id
            ) p ON p.invoice_id = i.id
            WHERE i.status IN ('ISSUED','PARTIALLY_PAID','OVERDUE')
            """
        )["c"]
        return DashboardStats(buildings, apartments, residents, open_invoices, int(unpaid_amount or 0))

    def recent_invoices(self) -> list[dict]:
        return self.db.fetch_all(
            """
            SELECT i.id, i.invoice_no, a.code AS apartment_code, i.billing_month, i.total_amount,
                   COALESCE(p.paid, 0) AS paid_amount,
                   i.status
            FROM invoices i
            JOIN apartments a ON a.id = i.apartment_id
            LEFT JOIN (
                SELECT invoice_id, SUM(amount) AS paid
                FROM payments
                GROUP BY invoice_id
            ) p ON p.invoice_id = i.id
            ORDER BY i.id DESC
            LIMIT 8
            """
        )

    def buildings(self) -> list[dict]:
        return self.db.fetch_all("SELECT id, code, name FROM buildings ORDER BY code")

    def apartments(self, keyword: str = "") -> list[dict]:
        q = """
            SELECT a.id, b.code AS building_code, a.code, a.floor, a.area_m2, a.bedroom_count,
                   a.is_furnished, a.has_balcony, a.status,
                   COALESCE(occ.active_residents, 0) AS active_residents
            FROM apartments a
            JOIN buildings b ON b.id = a.building_id
            LEFT JOIN (
                SELECT apartment_id, COUNT(*) AS active_residents
                FROM occupancies
                WHERE status = 'ACTIVE'
                GROUP BY apartment_id
            ) occ ON occ.apartment_id = a.id
            WHERE a.code LIKE ? OR b.code LIKE ?
            ORDER BY a.id ASC, b.code, a.floor, a.code
        """
        like = f"%{keyword.strip()}%"
        return self.db.fetch_all(q, (like, like))

    def apartment_detail(self, apartment_id: int) -> dict | None:
        apartment = self.db.fetch_one(
            """
            SELECT a.id, a.code, a.floor, a.area_m2, a.bedroom_count, a.status,
                   a.is_furnished, a.has_balcony,
                   b.code AS building_code, b.name AS building_name
            FROM apartments a
            JOIN buildings b ON b.id = a.building_id
            WHERE a.id = ?
            """,
            (apartment_id,),
        )
        if apartment is None:
            return None
        residents = self.db.fetch_all(
            """
            SELECT r.resident_code, r.full_name, o.move_in_date, o.is_primary_resident, o.status
            FROM occupancies o
            JOIN residents r ON r.id = o.resident_id
            WHERE o.apartment_id = ?
            ORDER BY o.status DESC, o.is_primary_resident DESC, r.full_name
            """,
            (apartment_id,),
        )
        meters = self.db.fetch_all(
            "SELECT meter_type, serial_no, status FROM meters WHERE apartment_id = ? ORDER BY meter_type",
            (apartment_id,),
        )
        latest_invoice = self.db.fetch_one(
            """
            SELECT invoice_no, billing_month, total_amount, status
            FROM invoices
            WHERE apartment_id = ?
            ORDER BY id DESC
            LIMIT 1
            """,
            (apartment_id,),
        )
        return {
            "apartment": apartment,
            "residents": residents,
            "meters": meters,
            "latest_invoice": latest_invoice,
        }

    def residents(self, keyword: str = "") -> list[dict]:
        q = """
            SELECT r.id, r.resident_code, r.full_name, r.phone, r.national_id, r.date_of_birth, r.status,
                   COALESCE(oa.apartment_code, '-') AS apartment_code,
                   COALESCE(oa.move_in_date, '-') AS move_in_date
            FROM residents r
            LEFT JOIN (
                SELECT o.resident_id, a.code AS apartment_code, o.move_in_date
                FROM occupancies o
                JOIN apartments a ON a.id = o.apartment_id
                WHERE o.status = 'ACTIVE'
            ) oa ON oa.resident_id = r.id
            WHERE r.resident_code LIKE ? OR r.full_name LIKE ? OR r.phone LIKE ?
            ORDER BY r.id ASC
        """
        like = f"%{keyword.strip()}%"
        return self.db.fetch_all(q, (like, like, like))

    def meters(self) -> list[dict]:
        return self.db.fetch_all(
            """
            SELECT m.id, a.code AS apartment_code, m.meter_type, m.serial_no, m.status
            FROM meters m
            JOIN apartments a ON a.id = m.apartment_id
            WHERE m.status = 'ACTIVE'
            ORDER BY m.id ASC
            """
        )

    def meter_readings(self, keyword: str = "") -> list[dict]:
        q = """
            SELECT mr.id, a.code AS apartment_code, m.meter_type, m.serial_no,
                   mr.reading_date, mr.previous_value, mr.current_value,
                   mr.current_value - mr.previous_value AS usage
            FROM meter_readings mr
            JOIN meters m ON m.id = mr.meter_id
            JOIN apartments a ON a.id = m.apartment_id
            WHERE a.code LIKE ? OR m.serial_no LIKE ? OR m.meter_type LIKE ?
            ORDER BY mr.id ASC
        """
        like = f"%{keyword.strip()}%"
        return self.db.fetch_all(q, (like, like, like))

    def latest_meter_value(self, meter_id: int) -> int:
        row = self.db.fetch_one(
            "SELECT current_value FROM meter_readings WHERE meter_id = ? ORDER BY reading_date DESC, id DESC LIMIT 1",
            (meter_id,),
        )
        return int(row["current_value"]) if row else 0

    def invoices(self, keyword: str = "") -> list[dict]:
        q = """
            SELECT i.id, i.invoice_no, a.code AS apartment_code, i.billing_month, i.due_date,
                   i.total_amount, COALESCE(p.paid, 0) AS paid_amount,
                   i.total_amount - COALESCE(p.paid, 0) AS outstanding_amount,
                   i.status
            FROM invoices i
            JOIN apartments a ON a.id = i.apartment_id
            LEFT JOIN (
                SELECT invoice_id, SUM(amount) AS paid
                FROM payments
                GROUP BY invoice_id
            ) p ON p.invoice_id = i.id
            WHERE i.invoice_no LIKE ? OR a.code LIKE ? OR i.billing_month LIKE ?
            ORDER BY i.id ASC
        """
        like = f"%{keyword.strip()}%"
        return self.db.fetch_all(q, (like, like, like))

    def invoice_lines(self, invoice_id: int) -> list[dict]:
        return self.db.fetch_all(
            """
            SELECT item_code, description, quantity, unit, unit_price, amount
            FROM invoice_lines
            WHERE invoice_id = ?
            ORDER BY id
            """,
            (invoice_id,),
        )

    def payments(self, invoice_id: int | None = None) -> list[dict]:
        if invoice_id is None:
            return self.db.fetch_all(
                """
                SELECT p.id, i.invoice_no, p.payment_date, p.amount, p.method, p.reference_no, p.note
                FROM payments p
                JOIN invoices i ON i.id = p.invoice_id
                ORDER BY p.id ASC
                LIMIT 100
                """
            )
        return self.db.fetch_all(
            """
            SELECT p.id, i.invoice_no, p.payment_date, p.amount, p.method, p.reference_no, p.note
            FROM payments p
            JOIN invoices i ON i.id = p.invoice_id
            WHERE p.invoice_id = ?
            ORDER BY p.id ASC
            """,
            (invoice_id,),
        )


class CommandService:
    def __init__(self, db: Database) -> None:
        self.db = db

    def add_apartment(
        self,
        building_id: int,
        code: str,
        floor: int,
        area_m2: float,
        bedroom_count: int,
        is_furnished: bool,
        has_balcony: bool,
        status: str,
    ) -> int:
        timestamp = now_iso()
        return self.db.execute(
            """
            INSERT INTO apartments (
                building_id, code, floor, area_m2, bedroom_count,
                is_furnished, has_balcony, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                building_id,
                code.strip().upper(),
                floor,
                area_m2,
                bedroom_count,
                1 if is_furnished else 0,
                1 if has_balcony else 0,
                status,
                timestamp,
                timestamp,
            ),
        )

    def add_resident(
        self,
        resident_code: str,
        full_name: str,
        phone: str,
        national_id: str,
        date_of_birth: str,
        status: str,
    ) -> int:
        timestamp = now_iso()
        return self.db.execute(
            """
            INSERT INTO residents (
                resident_code, full_name, phone, national_id,
                date_of_birth, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                resident_code.strip().upper(),
                full_name.strip(),
                phone.strip(),
                national_id.strip(),
                date_of_birth,
                status,
                timestamp,
                timestamp,
            ),
        )

    def add_meter_reading(
        self,
        meter_id: int,
        reading_date: str,
        previous_value: int,
        current_value: int,
    ) -> int:
        if current_value < previous_value:
            raise ValueError("Chi so moi khong duoc nho hon chi so cu.")
        return self.db.execute(
            """
            INSERT INTO meter_readings (
                meter_id, reading_date, previous_value, current_value, recorded_at
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (meter_id, reading_date, previous_value, current_value, now_iso()),
        )

    def add_payment(
        self,
        invoice_id: int,
        payment_date: str,
        amount: int,
        method: str,
        reference_no: str,
        note: str,
    ) -> int:
        if amount <= 0:
            raise ValueError("So tien thanh toan phai lon hon 0.")
        invoice = self.db.fetch_one("SELECT total_amount FROM invoices WHERE id = ?", (invoice_id,))
        if invoice is None:
            raise ValueError("Khong tim thay hoa don.")
        paid_row = self.db.fetch_one(
            "SELECT COALESCE(SUM(amount), 0) AS paid FROM payments WHERE invoice_id = ?",
            (invoice_id,),
        )
        already_paid = int(paid_row["paid"] or 0)
        total = int(invoice["total_amount"])
        if already_paid + amount > total:
            raise ValueError("Tong thanh toan dang vuot qua tong hoa don.")

        payment_id = self.db.execute(
            """
            INSERT INTO payments (
                invoice_id, payment_date, amount, method, reference_no, note, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (invoice_id, payment_date, amount, method, reference_no.strip(), note.strip(), now_iso()),
        )

        new_paid = already_paid + amount
        new_status = "PAID" if new_paid >= total else "PARTIALLY_PAID"
        self.db.execute(
            "UPDATE invoices SET status = ? WHERE id = ?",
            (new_status, invoice_id),
        )
        return payment_id

    def addOccupancy(
        self,
        apartment_id: int,
        resident_id: int | None,
        move_in_date: str,
        is_primary: bool,
        move_out_date: str | None = None,
    ) -> int:
        """Thêm một bản ghi cư trú mới (Occupancy)."""
        if resident_id is None:
            raise ValueError("Vui lòng chọn cư dân hợp lệ.")

        timestamp = now_iso()
        if is_primary:
            self.db.execute(
                "UPDATE occupancies SET is_primary_resident = 0 WHERE apartment_id = ? AND status = 'ACTIVE'",
                (apartment_id,),
            )

        occupancy_id = self.db.execute(
            """
            INSERT INTO occupancies (
                apartment_id, resident_id, move_in_date, move_out_date,
                is_primary_resident, status, created_at
            ) VALUES (?, ?, ?, ?, ?, 'ACTIVE', ?)
            """,
            (
                apartment_id,
                resident_id,
                move_in_date,
                move_out_date,
                1 if is_primary else 0,
                timestamp,
            ),
        )
        self.db.execute("UPDATE apartments SET status = 'OCCUPIED' WHERE id = ?", (apartment_id,))
        return occupancy_id

    def removeOccupancy(self, apartment_id: int, resident_code: str) -> None:
        """Xóa cư dân cụ thể dựa trên mã cư dân và id căn hộ."""
        self.db.execute(
            """
            DELETE FROM occupancies
            WHERE apartment_id = ?
              AND resident_id = (SELECT id FROM residents WHERE resident_code = ?)
            """,
            (apartment_id, resident_code),
        )
        remaining = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM occupancies WHERE apartment_id = ? AND status = 'ACTIVE'",
            (apartment_id,),
        )
        if int(remaining['c']) == 0:
            self.db.execute("UPDATE apartments SET status = 'VACANT' WHERE id = ?", (apartment_id,))

    def _billing_period(self, billing_month: str) -> tuple[str, str, str]:
        if not re.fullmatch(r"\d{4}-\d{2}", billing_month.strip()):
            raise ValueError("Kỳ hóa đơn phải theo định dạng YYYY-MM.")
        year_s, month_s = billing_month.split("-")
        year = int(year_s)
        month = int(month_s)
        if month < 1 or month > 12:
            raise ValueError("Tháng trong kỳ hóa đơn không hợp lệ.")
        last_day = calendar.monthrange(year, month)[1]
        period_start = date(year, month, 1)
        period_end = date(year, month, last_day)
        due_date = period_end + timedelta(days=10)
        return period_start.isoformat(), period_end.isoformat(), due_date.isoformat()

    def _service_rate(self, building_id: int, service_type: str, on_date: str) -> dict | None:
        return self.db.fetch_one(
            """
            SELECT id, service_type, unit, unit_price
            FROM service_rates
            WHERE building_id = ?
              AND service_type = ?
              AND effective_from <= ?
              AND (effective_to IS NULL OR effective_to = '' OR effective_to >= ?)
            ORDER BY effective_from DESC, id DESC
            LIMIT 1
            """,
            (building_id, service_type, on_date, on_date),
        )

    def _latest_usage_for_meter(self, meter_id: int, period_end: str) -> int:
        rows = self.db.fetch_all(
            """
            SELECT current_value
            FROM meter_readings
            WHERE meter_id = ? AND reading_date <= ?
            ORDER BY reading_date DESC, id DESC
            LIMIT 2
            """,
            (meter_id, period_end),
        )
        if len(rows) < 2:
            return 0
        usage = int(rows[0]['current_value']) - int(rows[1]['current_value'])
        return max(0, usage)

    def create_invoice(
        self,
        apartment_id: int,
        billing_month: str,
        bike_count: int,
        car_count: int,
        other_fee: float = 0,
        due_date: str | None = None,
    ) -> int:
        """Phát hành hóa đơn theo schema DB hiện tại."""
        billing_month = billing_month.strip()
        period_start, period_end, default_due_date = self._billing_period(billing_month)
        due_date = (due_date or default_due_date).strip()

        existed = self.db.fetch_one(
            "SELECT id FROM invoices WHERE apartment_id = ? AND billing_month = ?",
            (apartment_id, billing_month),
        )
        if existed:
            raise ValueError("Căn hộ này đã có hóa đơn cho kỳ đã chọn.")

        apartment = self.db.fetch_one(
            "SELECT id, code, area_m2, building_id FROM apartments WHERE id = ?",
            (apartment_id,),
        )
        if apartment is None:
            raise ValueError("Không tìm thấy căn hộ.")

        building_id = int(apartment['building_id'])
        area_m2 = float(apartment['area_m2'])
        apt_code = apartment['code']
        lines: list[tuple[int | None, str, str, float, str, int, int]] = []
        subtotal = 0

        month_text = f"{billing_month[5:7]}/{billing_month[:4]}"
        rate_date = period_end

        def append_line(rate: dict | None, item_code: str, description: str, quantity: float, unit: str, unit_price: int):
            nonlocal subtotal
            if quantity <= 0 or unit_price < 0:
                return
            amount = int(round(quantity * unit_price))
            lines.append((int(rate['id']) if rate else None, item_code, description, quantity, unit, int(unit_price), amount))
            subtotal += amount

        mgmt_rate = self._service_rate(building_id, 'MANAGEMENT', rate_date)
        if mgmt_rate:
            append_line(mgmt_rate, 'MGMT', f'Phí quản lý tháng {month_text}', area_m2, mgmt_rate['unit'], int(mgmt_rate['unit_price']))

        meters = self.db.fetch_all(
            "SELECT id, meter_type FROM meters WHERE apartment_id = ? AND status = 'ACTIVE' ORDER BY id",
            (apartment_id,),
        )
        for meter in meters:
            meter_type = meter['meter_type']
            usage = self._latest_usage_for_meter(int(meter['id']), period_end)
            if meter_type == 'ELECTRICITY':
                rate = self._service_rate(building_id, 'ELECTRICITY', rate_date)
                if rate:
                    append_line(rate, 'ELEC', f'Tiền điện tháng {month_text}', usage, rate['unit'], int(rate['unit_price']))
            elif meter_type == 'WATER':
                rate = self._service_rate(building_id, 'WATER', rate_date)
                if rate:
                    append_line(rate, 'WATR', f'Tiền nước tháng {month_text}', usage, rate['unit'], int(rate['unit_price']))

        bike_rate = self._service_rate(building_id, 'PARKING_MOTORBIKE', rate_date)
        if bike_rate and bike_count > 0:
            append_line(bike_rate, 'PKMB', f'Phí gửi xe máy tháng {month_text}', float(bike_count), bike_rate['unit'], int(bike_rate['unit_price']))

        car_rate = self._service_rate(building_id, 'PARKING_CAR', rate_date)
        if car_rate and car_count > 0:
            append_line(car_rate, 'PKCR', f'Phí gửi ô tô tháng {month_text}', float(car_count), car_rate['unit'], int(car_rate['unit_price']))

        clean_rate = self._service_rate(building_id, 'CLEANING', rate_date)
        if clean_rate:
            append_line(clean_rate, 'CLEN', f'Phí vệ sinh tháng {month_text}', 1.0, clean_rate['unit'], int(clean_rate['unit_price']))

        maint_rate = self._service_rate(building_id, 'MAINTENANCE', rate_date)
        if maint_rate:
            append_line(maint_rate, 'MAINT', f'Phí bảo trì tháng {month_text}', 1.0, maint_rate['unit'], int(maint_rate['unit_price']))

        other_value = int(round(other_fee or 0))
        if other_value > 0:
            other_rate = self._service_rate(building_id, 'OTHER', rate_date)
            append_line(other_rate, 'OTHR', f'Phí khác tháng {month_text}', 1.0, 'apartment', other_value)

        invoice_no = f"INV-{billing_month.replace('-', '')}-{apt_code}"
        issued_at = now_iso()
        invoice_id = self.db.execute(
            """
            INSERT INTO invoices (
                apartment_id, invoice_no, billing_month, period_start, period_end,
                due_date, subtotal, total_amount, status, issued_at, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ISSUED', ?, ?)
            """,
            (
                apartment_id,
                invoice_no,
                billing_month,
                period_start,
                period_end,
                due_date,
                subtotal,
                subtotal,
                issued_at,
                issued_at,
            ),
        )

        for service_rate_id, item_code, description, quantity, unit, unit_price, amount in lines:
            self.db.execute(
                """
                INSERT INTO invoice_lines (
                    invoice_id, service_rate_id, item_code, description,
                    quantity, unit, unit_price, amount
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    invoice_id,
                    service_rate_id,
                    item_code,
                    description,
                    quantity,
                    unit,
                    unit_price,
                    amount,
                ),
            )

    def transfer_resident(self, resident_id: int, old_apt_id: int, new_apt_id: int) -> None:
        timestamp = now_iso()
        start_dt = datetime.fromisoformat(timestamp)
        today_str = start_dt.strftime('%Y-%m-%d')

        duration = random.randint(6, 24)
        end_year = start_dt.year + (start_dt.month + duration - 1) // 12
        end_month = (start_dt.month + duration - 1) % 12 + 1
        last_day = calendar.monthrange(end_year, end_month)[1]
        end_date_str = f"{end_year:04d}-{end_month:02d}-{last_day:02d}"
        monthly_rent = random.randrange(4000000, 12000000, 500000)
        deposit_amount = monthly_rent * 2


        self.db.execute(
            "UPDATE occupancies SET status = 'MOVED_OUT' WHERE resident_id = ? AND apartment_id = ? AND status = 'ACTIVE'",
            (resident_id, old_apt_id)
        )

        check_new = self.db.fetch_one(
            "SELECT COUNT(*) as c FROM occupancies WHERE apartment_id = ? AND status = 'ACTIVE'", (new_apt_id,))
        is_primary = 1 if int(check_new['c']) == 0 else 0
        self.db.execute(
            "INSERT INTO occupancies (apartment_id, resident_id, move_in_date, is_primary_resident, status, created_at) VALUES (?, ?, ?, ?, 'ACTIVE', ?)",
            (new_apt_id, resident_id, today_str, is_primary, timestamp)
        )

        new_contract_no = f"LC-{start_dt.year}-{random.randint(1000, 9999)}"
        self.db.execute(
            """
            INSERT INTO lease_contracts (
                contract_no, apartment_id, resident_id, start_date, end_date, 
                monthly_rent, deposit_amount, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?)
            """,
            (new_contract_no, new_apt_id, resident_id, today_str, end_date_str,
             monthly_rent, deposit_amount, timestamp, timestamp)
        )
        self.db.execute(
            "INSERT INTO apartment_owners (apartment_id, resident_id, ownership_from, is_primary_owner, created_at) VALUES (?, ?, ?, 1, ?)",
            (new_apt_id, resident_id, today_str, timestamp)
        )

        self.db.execute("UPDATE apartments SET status = 'OCCUPIED' WHERE id = ?", (new_apt_id,))
        self.db.execute("UPDATE meters SET status = 'ACTIVE' WHERE apartment_id = ?", (new_apt_id,))
        rem = self.db.fetch_one("SELECT COUNT(*) as c FROM occupancies WHERE apartment_id = ? AND status = 'ACTIVE'",
                                (old_apt_id,))

        if int(rem['c']) == 0:
            self.db.execute("UPDATE apartments SET status = 'VACANT' WHERE id = ?", (old_apt_id,))
            self.db.execute("UPDATE meters SET status = 'INACTIVE' WHERE apartment_id = ?", (old_apt_id,))