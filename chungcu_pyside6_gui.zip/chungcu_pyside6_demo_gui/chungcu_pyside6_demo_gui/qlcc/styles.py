APP_STYLE = """
QWidget {
    font-size: 14px;
    color: #203047;
}
QMainWindow {
    background: #f4f7fb;
}
QWidget#Root {
    background: #f4f7fb;
}
QFrame#Sidebar {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #1f4c8f, stop:1 #163866);
    border-radius: 24px;
}
QLabel#BrandEyebrow {
    color: rgba(255,255,255,0.72);
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 1px;
}
QLabel#BrandTitle {
    color: white;
    font-size: 24px;
    font-weight: 800;
}
QLabel#BrandSub {
    color: rgba(255,255,255,0.86);
    font-size: 13px;
}
QListWidget {
    background: transparent;
    color: rgba(255,255,255,0.92);
    border: none;
    outline: none;
    font-weight: 600;
}
QListWidget::item {
    padding: 12px 14px;
    border-radius: 12px;
    margin: 4px 0;
}
QListWidget::item:hover {
    background: rgba(255,255,255,0.10);
}
QListWidget::item:selected {
    background: rgba(255,255,255,0.16);
    border: 1px solid rgba(255,255,255,0.14);
}
QFrame#ContentSurface {
    background: transparent;
}
QLabel#PageTitle {
    color: #12233d;
    font-size: 26px;
    font-weight: 800;
}
QLabel#PageSubtitle {
    color: #64748b;
    font-size: 13px;
}
QFrame#Card {
    background: white;
    border: 1px solid #e3ebf6;
    border-radius: 18px;
}
QLabel#CardValue {
    font-size: 28px;
    font-weight: 800;
    color: #12233d;
}
QLabel#CardTitle {
    color: #64748b;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.5px;
}
QPushButton {
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 10px;
    padding: 10px 14px;
    font-weight: 700;
}
QPushButton:hover {
    background: #1d4ed8;
}
QPushButton:pressed {
    background: #1e40af;
}
QPushButton[variant="secondary"] {
    background: white;
    color: #23407a;
    border: 1px solid #d9e5f6;
}
QPushButton[variant="secondary"]:hover {
    background: #f8fbff;
}
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit {
    background: white;
    border: 1px solid #d7e2f0;
    border-radius: 10px;
    padding: 9px 10px;
    selection-background-color: #2563eb;
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus {
    border: 1px solid #2563eb;
}
QComboBox::drop-down {
    border: none;
    width: 26px;
}
QTableWidget {
    background: white;
    border: 1px solid #e3ebf6;
    border-radius: 16px;
    gridline-color: #edf2f8;
    alternate-background-color: #f8fbff;
    selection-background-color: #dbeafe;
    selection-color: #12233d;
}
QHeaderView::section {
    background: #f4f8fd;
    color: #334155;
    border: none;
    border-bottom: 1px solid #e3ebf6;
    padding: 10px 8px;
    font-weight: 800;
}
QGroupBox {
    font-weight: 800;
    color: #1e293b;
    border: 1px solid #e3ebf6;
    border-radius: 16px;
    margin-top: 12px;
    background: white;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 14px;
    padding: 0 6px;
}
QMessageBox {
    background: white;
}
"""
