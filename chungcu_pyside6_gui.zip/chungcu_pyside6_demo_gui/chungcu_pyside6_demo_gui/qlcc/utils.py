from __future__ import annotations

from datetime import datetime


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def format_money(value: int | float | None) -> str:
    if value is None:
        return "0 VND"
    return f"{int(value):,} VND"
