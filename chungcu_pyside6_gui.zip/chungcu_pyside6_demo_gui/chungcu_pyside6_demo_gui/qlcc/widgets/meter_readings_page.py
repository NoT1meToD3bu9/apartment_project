from __future__ import annotations

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from qlcc.services import CommandService, QueryService
from qlcc.widgets.common import PageHeader, make_toolbar, secondary_button, set_table_data, show_error, show_info


class MeterReadingsPage(QWidget):
    def __init__(self, queries: QueryService, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries
        self.commands = commands
        self.meter_map: dict[str, int] = {}

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("Chỉ số công tơ", "Nhập chỉ số điện nước mới và theo dõi lịch sử chốt số theo từng căn hộ."))

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tìm theo căn hộ, serial hoặc loại công tơ...")
        self.refresh_button = secondary_button("Làm mới")
        layout.addWidget(make_toolbar(self.search_edit, self.refresh_button))

        body = QHBoxLayout()
        body.setSpacing(16)
        self.table = QTableWidget()
        body.addWidget(self.table, 3)

        form_group = QGroupBox("Thêm chỉ số mới")
        form = QFormLayout(form_group)
        self.meter_combo = QComboBox()
        self.reading_date = QDateEdit()
        self.reading_date.setCalendarPopup(True)
        self.reading_date.setDate(QDate.currentDate())
        self.prev_spin = QSpinBox()
        self.prev_spin.setRange(0, 10_000_000)
        self.curr_spin = QSpinBox()
        self.curr_spin.setRange(0, 10_000_000)
        self.save_button = QPushButton("Lưu chỉ số")

        form.addRow("Công tơ", self.meter_combo)
        form.addRow("Ngày ghi", self.reading_date)
        form.addRow("Chỉ số cũ", self.prev_spin)
        form.addRow("Chỉ số mới", self.curr_spin)
        form.addRow("", self.save_button)
        body.addWidget(form_group, 2)
        layout.addLayout(body, 1)

        self.search_edit.textChanged.connect(self.refresh)
        self.refresh_button.clicked.connect(self.refresh)
        self.save_button.clicked.connect(self.save_reading)
        self.meter_combo.currentTextChanged.connect(self.sync_previous_value)

        self.load_meters()
        self.refresh()

    def load_meters(self) -> None:
        self.meter_combo.blockSignals(True)
        self.meter_combo.clear()
        self.meter_map.clear()
        for meter in self.queries.meters():
            label = f"{meter['apartment_code']} | {meter['meter_type']} | {meter['serial_no']}"
            self.meter_map[label] = int(meter["id"])
            self.meter_combo.addItem(label)
        self.meter_combo.blockSignals(False)
        self.sync_previous_value()

    def sync_previous_value(self) -> None:
        label = self.meter_combo.currentText()
        if not label:
            self.prev_spin.setValue(0)
            return

        meter_id = self.meter_map.get(label)
        if meter_id is None:
            self.prev_spin.setValue(0)
            return

        prev = self.queries.latest_meter_value(meter_id)
        self.prev_spin.setValue(prev)
        if self.curr_spin.value() < prev:
            self.curr_spin.setValue(prev)

    def refresh(self) -> None:
        rows = []
        for row in self.queries.meter_readings(self.search_edit.text()):
            rows.append(
                [
                    row["id"],
                    row["apartment_code"],
                    row["meter_type"],
                    row["serial_no"],
                    row["reading_date"],
                    row["previous_value"],
                    row["current_value"],
                    row["usage"],
                ]
            )
        set_table_data(
            self.table,
            ["ID", "CĂN", "LOẠI", "SERIAL", "NGÀY GHI", "SỐ CŨ", "SỐ MỚI", "TIÊU THỤ"],
            rows,
        )

    def save_reading(self) -> None:
        try:
            label = self.meter_combo.currentText()
            meter_id = self.meter_map.get(label)
            if meter_id is None:
                raise ValueError("Không tìm thấy công tơ hợp lệ. Thử tải lại danh sách công tơ.")

            self.commands.add_meter_reading(
                meter_id=meter_id,
                reading_date=self.reading_date.date().toString("yyyy-MM-dd"),
                previous_value=self.prev_spin.value(),
                current_value=self.curr_spin.value(),
            )
            show_info(self, "Đã lưu chỉ số mới.")
            self.refresh()
            self.sync_previous_value()
        except Exception as exc:
            show_error(self, str(exc))
