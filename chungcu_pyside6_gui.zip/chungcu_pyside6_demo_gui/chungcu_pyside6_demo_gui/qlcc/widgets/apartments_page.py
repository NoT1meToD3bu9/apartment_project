from __future__ import annotations
from PySide6.QtCore import QDate

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from qlcc.services import CommandService, QueryService
from qlcc.utils import format_money
from qlcc.widgets.common import PageHeader, make_toolbar, secondary_button, set_table_data, show_error, show_info


class AddApartmentDialog(QDialog):
    def __init__(self, queries: QueryService, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries
        self.commands = commands
        self.setWindowTitle("Thêm căn hộ")
        self.resize(420, 360)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.building_combo = QComboBox()
        self.building_map: dict[str, int] = {}
        self.resident_combo = QComboBox()
        self.resident_combo.addItem("-- Chưa gán cư dân --", None)
        for res in self.queries.residents(""):
            self.resident_combo.addItem(f"{res['full_name']} ({res['resident_code']})", res['id'])
        for b in self.queries.buildings():
            label = f"{b['code']} - {b['name']}"
            self.building_map[label] = int(b["id"])
            self.building_combo.addItem(label)


        self.move_in_edit = QDateEdit()
        self.move_in_edit.setCalendarPopup(True)
        self.move_in_edit.setDate(QDate.currentDate())
        self.has_move_out = QCheckBox("Có ngày dọn ra dự kiến")
        self.move_out_edit = QDateEdit()
        self.move_out_edit.setCalendarPopup(True)
        self.move_out_edit.setDate(QDate.currentDate().addMonths(12))
        self.move_out_edit.setEnabled(False)
        self.has_move_out.toggled.connect(self.move_out_edit.setEnabled)
        self.is_primary_combo = QComboBox()
        self.is_primary_combo.addItems(["Không", "Có"])
        self.code_edit = QLineEdit()
        self.floor_spin = QSpinBox()
        self.floor_spin.setRange(1, 100)
        self.area_spin = QDoubleSpinBox()
        self.area_spin.setRange(1, 1000)
        self.area_spin.setDecimals(2)
        self.bedroom_spin = QSpinBox()
        self.bedroom_spin.setRange(0, 20)
        self.furnished_check = QCheckBox("Có nội thất")
        self.balcony_check = QCheckBox("Có ban công")
        self.status_combo = QComboBox()
        self.status_combo.addItems(["VACANT", "OCCUPIED", "MAINTENANCE"])

        form.addRow("Tòa nhà", self.building_combo)
        form.addRow("Mã căn", self.code_edit)
        form.addRow("Tầng", self.floor_spin)
        form.addRow("Diện tích (m²)", self.area_spin)
        form.addRow("Số phòng ngủ", self.bedroom_spin)
        form.addRow("Nội thất", self.furnished_check)
        form.addRow("Ban công", self.balcony_check)
        form.addRow("Trạng thái", self.status_combo)
        form.addRow("Chọn cư dân:", self.resident_combo)
        form.addRow("Ngày chuyển vào:", self.move_in_edit)
        form.addRow(self.has_move_out, self.move_out_edit)
        form.addRow("Cư dân đại diện:", self.is_primary_combo)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_data(self):
        move_out = None
        # Nếu người dùng tick vào ô "Có ngày dọn ra" thì mới lấy giá trị
        if self.has_move_out.isChecked():
            move_out = self.move_out_edit.date().toString("yyyy-MM-dd")
            
        return {
            "resident_id": self.resident_combo.currentData(),
            "move_in_date": self.move_in_edit.date().toString("yyyy-MM-dd"),
            "move_out_date": move_out, # Sẽ là None (NULL) nếu không tick
            "is_primary": self.is_primary_combo.currentText() == "Có"
        }
    
    def save(self) -> None:
        label = self.building_combo.currentText()
        building_id = self.building_map[label]
        apt_id = self.commands.add_apartment(
            building_id=building_id,
            code=self.code_edit.text(),
            floor=self.floor_spin.value(),
            area_m2=self.area_spin.value(),
            bedroom_count=self.bedroom_spin.value(),
            is_furnished=self.furnished_check.isChecked(),
            has_balcony=self.balcony_check.isChecked(),
            status=self.status_combo.currentText(),
        )
        res_data = self.get_data()
        if res_data["resident_id"] is not None:
            self.commands.addOccupancy(
                apartment_id=apt_id,
                resident_id=res_data["resident_id"],
                move_in_date=res_data["move_in_date"],
                is_primary=res_data["is_primary"],
                move_out_date=res_data["move_out_date"],
            )

class AssignResidentDialog(QDialog):
    def __init__(self, queries: QueryService, apartment_id: int, parent=None):
        super().__init__(parent)
        self.queries = queries
        self.apartment_id = apartment_id
        self.found_resident_id = None # Lưu ID tìm được
        
        self.setWindowTitle("Gán cư dân vào căn hộ")
        self.setMinimumWidth(400)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        # Ô NHẬP MÃ: Dùng QLineEdit thay vì QComboBox
        self.resident_code_edit = QLineEdit()
        self.resident_code_edit.setPlaceholderText("Nhập chính xác mã cư dân...")
        
        # Ô HIỂN THỊ TÊN: Chỉ để đọc, giúp xác nhận đúng người
        self.resident_name_display = QLineEdit()
        self.resident_name_display.setReadOnly(True)
        self.resident_name_display.setPlaceholderText("Tên cư dân sẽ hiện ở đây")
        self.resident_name_display.setStyleSheet("background-color: #eeeeee;")

        # Kết nối sự kiện: Khi gõ chữ thì tự tìm tên
        self.resident_code_edit.textChanged.connect(self.lookup_resident)

        self.move_in_edit = QDateEdit()
        self.move_in_edit.setCalendarPopup(True)
        self.move_in_edit.setDate(QDate.currentDate())

        self.is_primary_combo = QComboBox()
        self.is_primary_combo.addItems(["Không", "Có"])

        form.addRow("Mã cư dân:", self.resident_code_edit)
        form.addRow("Họ tên:", self.resident_name_display)
        form.addRow("Ngày chuyển vào:", self.move_in_edit)
        form.addRow("Cư dân đại diện:", self.is_primary_combo)
        layout.addLayout(form)

        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False) # Khóa nút Ok ban đầu
        layout.addWidget(self.buttons)

    def lookup_resident(self, code):
        code = code.strip().upper()
        if not code:
            self.resident_name_display.clear()
            self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
            return

        # Tìm trong database qua QueryService
        results = self.queries.residents(code)
        # Tìm bản ghi khớp chính xác mã
        match = next((r for r in results if r["resident_code"].upper() == code), None)

        if match:
            self.resident_name_display.setText(match["full_name"])
            self.found_resident_id = match["id"]
            self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)
        else:
            self.resident_name_display.setText("⚠️ Không tìm thấy mã này")
            self.found_resident_id = None
            self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)

    def get_data(self):
        return {
            "resident_id": self.found_resident_id,
            "move_in_date": self.move_in_edit.date().toString("yyyy-MM-dd"),
            "is_primary": self.is_primary_combo.currentText() == "Có"
        }

class RemoveResidentDialog(QDialog):
    def __init__(self, residents: list[dict], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Xóa cư dân khỏi căn hộ")
        self.setMinimumWidth(350)
        
        layout = QVBoxLayout(self)
        form = QFormLayout()

        # Thanh cuộn chọn cư dân đang ở
        self.resident_combo = QComboBox()
        for res in residents:
            # Hiển thị: Mã - Tên (Ví dụ: R0815 - Dang Hong Hai)
            label = f"{res['resident_code']} - {res['full_name']}"
            self.resident_combo.addItem(label, res['resident_code'])

        form.addRow("Chọn cư dân cần xóa:", self.resident_combo)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_selected_code(self):
        return self.resident_combo.currentData()


class TransferApartmentDialog(QDialog):
    def __init__(self, vacant_apartments: list[dict], current_apt_name: str, residents: list[dict], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Chuyển cư dân sang phòng mới")
        self.setMinimumWidth(400)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.current_apt_label = QLineEdit(current_apt_name)
        self.current_apt_label.setReadOnly(True)
        self.current_apt_label.setStyleSheet("background-color: #f0f0f0;")
        self.resident_combo = QComboBox()
        for res in residents:
            label = f"{res['resident_code']} - {res['full_name']}"
            self.resident_combo.addItem(label, res['resident_code'])
        self.apt_combo = QComboBox()
        for apt in vacant_apartments:
            label = f"Tòa {apt['building_code']} - {apt['code']}"
            self.apt_combo.addItem(label, apt['id'])

        form.addRow("Phòng hiện tại:", self.current_apt_label)
        form.addRow("Chọn cư dân chuyển đi:", self.resident_combo)
        form.addRow("Chọn phòng mới:", self.apt_combo)
        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def get_data(self):
        return {
            "res_code": self.resident_combo.currentData(),
            "new_apt_id": self.apt_combo.currentData()
        }
class ApartmentsPage(QWidget):
    def __init__(self, queries: QueryService, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries
        self.commands = commands

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("Quản lý căn hộ", "Tra cứu danh sách căn, kiểm tra cư dân đang ở và xem nhanh hóa đơn gần nhất."))

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tìm theo mã căn hộ hoặc mã tòa nhà...")
        self.refresh_button = secondary_button("Làm mới")
        self.add_button = QPushButton("Thêm căn hộ")
        self.assign_button = QPushButton("Gán cư dân")
        self.remove_button = QPushButton("Xóa cư dân")
        self.transfer_button = QPushButton("Đổi phòng")
        toolbar = make_toolbar(self.search_edit, self.refresh_button)
        toolbar.layout().addWidget(self.assign_button)
        t_layout = toolbar.layout()
        t_layout.insertWidget(2, self.add_button)
        t_layout.insertWidget(3, self.assign_button)
        t_layout.insertWidget(4, self.remove_button)
        t_layout.insertWidget(5, self.transfer_button)
        layout.addWidget(toolbar)

        body = QHBoxLayout()
        body.setSpacing(16)
        self.table = QTableWidget()
        body.addWidget(self.table, 3)

        right_box = QVBoxLayout()
        self.detail_text = QTextEdit()
        self.detail_text.setReadOnly(True)
        self.detail_text.setPlaceholderText("Chọn một căn hộ để xem thông tin chi tiết.")
        group = QGroupBox("Chi tiết nhanh")
        group_layout = QVBoxLayout(group)
        group_layout.addWidget(self.detail_text)
        right_box.addWidget(group)
        body.addLayout(right_box, 2)
        layout.addLayout(body, 1)

        self.search_edit.textChanged.connect(self.refresh)
        self.refresh_button.clicked.connect(self.refresh)
        self.add_button.clicked.connect(self.open_add_dialog)
        self.table.itemSelectionChanged.connect(self.on_selection_changed)
        self.assign_button.clicked.connect(self.open_assign_dialog_from_toolbar)
        self.remove_button.clicked.connect(self.remove_resident_from_apartment)
        self.transfer_button.clicked.connect(self.open_transfer_dialog)
        self.refresh()

    def refresh(self) -> None:
        rows = []
        self._ids: list[int] = []
        for row in self.queries.apartments(self.search_edit.text()):
            self._ids.append(int(row["id"]))
            rows.append(
                [
                    row["id"],
                    row["building_code"],
                    row["code"],
                    row["floor"],
                    f"{row['area_m2']:.2f}",
                    row["bedroom_count"],
                    "Có" if row["is_furnished"] else "Không",
                    "Có" if row["has_balcony"] else "Không",
                    row["active_residents"],
                    row["status"],
                ]
            )
        set_table_data(
            self.table,
            ["ID", "TÒA", "CĂN", "TẦNG", "DIỆN TÍCH", "PHÒNG NGỦ", "NỘI THẤT", "BAN CÔNG", "CƯ DÂN", "TRẠNG THÁI"],
            rows,
        )
        if rows:
            self.table.selectRow(0)
        else:
            self.detail_text.clear()

    def on_selection_changed(self) -> None:
        row = self.table.currentRow()
        if row < 0 or row >= len(getattr(self, "_ids", [])):
            return
        apartment_id = self._ids[row]
        data = self.queries.apartment_detail(apartment_id)
        if not data:
            return
        apartment = data["apartment"]
        lines = [
            f"TÒA: {apartment['building_code']} - {apartment['building_name']}",
            f"CĂN: {apartment['code']} | TẦNG: {apartment['floor']}",
            f"DIỆN TÍCH: {apartment['area_m2']:.2f} m² | PHÒNG NGỦ: {apartment['bedroom_count']}",
            f"NỘI THẤT: {'Có' if apartment['is_furnished'] else 'Không'}",
            f"BAN CÔNG: {'Có' if apartment['has_balcony'] else 'Không'}",
            f"TRẠNG THÁI: {apartment['status']}",
            "",
            "CƯ DÂN:",
        ]
        residents = data["residents"]
        if residents:
            for resident in residents:
                lines.append(
                    f"- {resident['resident_code']} | {resident['full_name']} | vào ở {resident['move_in_date']}"
                    f" | đại diện: {'Có' if resident['is_primary_resident'] else 'Không'} | {resident['status']}"
                )
        else:
            lines.append("- Chưa có cư dân đang ở")
        lines.append("")
        lines.append("CÔNG TƠ:")
        for meter in data["meters"] or []:
            lines.append(f"- {meter['meter_type']} | {meter['serial_no']} | {meter['status']}")
        if not data["meters"]:
            lines.append("- Chưa có công tơ")
        lines.append("")
        latest_invoice = data["latest_invoice"]
        lines.append("HÓA ĐƠN GẦN NHẤT:")
        if latest_invoice:
            lines.append(
                f"- {latest_invoice['invoice_no']} | {latest_invoice['billing_month']} | "
                f"{format_money(latest_invoice['total_amount'])} | {latest_invoice['status']}"
            )
        else:
            lines.append("- Chưa có hóa đơn")
        self.detail_text.setPlainText("\n".join(lines))

    def open_add_dialog(self) -> None:
        dialog = AddApartmentDialog(self.queries, self.commands, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                dialog.save()
                show_info(self, "Đã thêm căn hộ mới.")
                self.refresh()
            except Exception as exc:
                show_error(self, str(exc))

    def open_transfer_dialog(self) -> None:
        row = self.table.currentRow()
        if row < 0:
            show_error(self, "Vui lòng chọn căn hộ muốn đổi phòng!")
            return

        old_apt_id = self._ids[row]
        data = self.queries.apartment_detail(old_apt_id)

        all_residents = data.get("residents", [])
        active_residents = [r for r in all_residents if r.get("status") == "ACTIVE"]

        if not active_residents:
            show_error(self, "Căn hộ này hiện không có cư dân nào đang ở (ACTIVE) để chuyển!")
            return

        all_apts = self.queries.apartments("")
        valid_apts = [
            a for a in all_apts
            if a["status"] in ("VACANT", "OCCUPIED") and int(a["id"]) != old_apt_id
        ]

        valid_apts.sort(key=lambda x: (x["building_code"], x["code"]))

        if not valid_apts:
            show_error(self, "Không có phòng phù hợp (Trống hoặc Đang ở) để chuyển đến!")
            return

        apt_info = data["apartment"]
        current_name = f"Tòa {apt_info['building_code']} - {apt_info['code']}"

        dialog = TransferApartmentDialog(valid_apts, current_name, active_residents, self)

        if dialog.exec() == QDialog.Accepted:
            result = dialog.get_data()
            try:
                res_info = self.queries.db.fetch_one(
                    "SELECT id FROM residents WHERE resident_code = ?",
                    (result["res_code"],)
                )

                if not res_info:
                    show_error(self, "Không tìm thấy mã cư dân này!")
                    return

                self.commands.transfer_resident(res_info["id"], old_apt_id, result["new_apt_id"])

                show_info(self, f"Cư dân {result['res_code']} đã được chuyển sang phòng mới thành công.")
                self.refresh()

            except Exception as e:
                show_error(self, f"Lỗi hệ thống: {str(e)}")
    def open_assign_dialog_from_toolbar(self) -> None:
        # Lấy dòng đang được chọn trong bảng
        row = self.table.currentRow()
        if row < 0:
            show_error(self, "Vui lòng chọn một căn hộ trong bảng trước khi gán!")
            return
            
        apartment_id = self._ids[row] 
        
        dialog = AssignResidentDialog(self.queries, apartment_id, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                data = dialog.get_data()
                # Gọi service để lưu vào bảng occupancies
                self.commands.addOccupancy(
                    apartment_id=apartment_id,
                    resident_id=data["resident_id"],
                    move_in_date=data["move_in_date"],
                    is_primary=data["is_primary"],
                    move_out_date=data.get("move_out_date")
                )
                show_info(self, "Gán cư dân vào căn hộ thành công!")
                self.refresh()
            except Exception as e:
                show_error(self, f"Lỗi: {str(e)}")

    def remove_resident_from_apartment(self) -> None:
        row = self.table.currentRow()
        if row < 0:
            show_error(self, "Vui lòng chọn một căn hộ trên bảng!")
            return
            
        apartment_id = self._ids[row]
        
        # Lấy dữ liệu chi tiết căn hộ để biết danh sách cư dân hiện tại
        data = self.queries.apartment_detail(apartment_id)
        residents = data.get("residents", [])
        
        if not residents:
            show_error(self, "Căn hộ này không có cư dân nào để xóa!")
            return

        # Mở Dialog có thanh cuộn chọn cư dân
        dialog = RemoveResidentDialog(residents, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            res_code = dialog.get_selected_code()
            try:
                self.commands.removeOccupancy(apartment_id, res_code)
                show_info(self, f"Đã xóa cư dân {res_code} khỏi căn hộ.")
                self.refresh()
            except Exception as e:
                show_error(self, f"Lỗi khi xóa: {str(e)}")