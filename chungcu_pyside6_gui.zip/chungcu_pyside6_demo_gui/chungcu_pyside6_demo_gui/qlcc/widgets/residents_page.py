from __future__ import annotations

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from qlcc.services import CommandService, QueryService
from qlcc.widgets.common import PageHeader, make_toolbar, secondary_button, set_table_data, show_error, show_info


class AddResidentDialog(QDialog):
    def __init__(self, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.commands = commands
        self.setWindowTitle("Thêm cư dân")
        self.resize(420, 320)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.code_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.phone_edit = QLineEdit()
        self.national_id_edit = QLineEdit()
        self.dob_edit = QDateEdit()
        self.dob_edit.setCalendarPopup(True)
        self.dob_edit.setDate(QDate.currentDate().addYears(-25))
        self.status_combo = QComboBox()
        self.status_combo.addItems(["ACTIVE", "INACTIVE"])

        form.addRow("Mã cư dân", self.code_edit)
        form.addRow("Họ tên", self.name_edit)
        form.addRow("Số điện thoại", self.phone_edit)
        form.addRow("CCCD", self.national_id_edit)
        form.addRow("Ngày sinh", self.dob_edit)
        form.addRow("Trạng thái", self.status_combo)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def save(self) -> None:
        self.commands.add_resident(
            resident_code=self.code_edit.text(),
            full_name=self.name_edit.text(),
            phone=self.phone_edit.text(),
            national_id=self.national_id_edit.text(),
            date_of_birth=self.dob_edit.date().toString("yyyy-MM-dd"),
            status=self.status_combo.currentText(),
        )


class ResidentsPage(QWidget):
    def __init__(self, queries: QueryService, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries
        self.commands = commands

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("Quản lý cư dân", "Theo dõi hồ sơ cư dân, thông tin liên hệ và căn hộ đang cư trú."))

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tìm theo mã, tên hoặc số điện thoại...")
        self.refresh_button = secondary_button("Làm mới")
        self.add_button = QPushButton("Thêm cư dân")
        layout.addWidget(make_toolbar(self.search_edit, self.refresh_button, self.add_button))

        self.table = QTableWidget()
        layout.addWidget(self.table, 1)

        self.search_edit.textChanged.connect(self.refresh)
        self.refresh_button.clicked.connect(self.refresh)
        self.add_button.clicked.connect(self.open_add_dialog)

        self.refresh()

    def refresh(self) -> None:
        rows = []
        for row in self.queries.residents(self.search_edit.text()):
            rows.append(
                [
                    row["id"],
                    row["resident_code"],
                    row["full_name"],
                    row["phone"],
                    row["national_id"],
                    row["date_of_birth"],
                    row["apartment_code"],
                    row["move_in_date"],
                    row["status"],
                ]
            )
        set_table_data(
            self.table,
            ["ID", "MÃ", "HỌ TÊN", "ĐIỆN THOẠI", "CCCD", "NGÀY SINH", "CĂN ĐANG Ở", "NGÀY VÀO Ở", "TRẠNG THÁI"],
            rows,
        )

    def open_add_dialog(self) -> None:
        dialog = AddResidentDialog(self.commands, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                dialog.save()
                show_info(self, "Đã thêm cư dân mới.")
                self.refresh()
            except Exception as exc:
                show_error(self, str(exc))
