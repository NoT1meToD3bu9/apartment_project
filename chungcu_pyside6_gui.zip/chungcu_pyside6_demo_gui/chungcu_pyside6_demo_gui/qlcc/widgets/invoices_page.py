from __future__ import annotations

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QVBoxLayout,
    QWidget,
    QLabel,
    QDoubleSpinBox,
)

from qlcc.services import CommandService, QueryService
from qlcc.utils import format_money
from qlcc.widgets.common import PageHeader, make_toolbar, secondary_button, set_table_data, show_error, show_info


class AddPaymentDialog(QDialog):
    def __init__(self, invoice: dict, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.invoice = invoice
        self.commands = commands
        self.setWindowTitle(f"Thanh toán - {invoice['invoice_no']}")
        self.resize(430, 280)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        self.amount_spin = QSpinBox()
        self.amount_spin.setRange(0, 1_000_000_000)
        self.amount_spin.setValue(max(0, int(invoice["outstanding_amount"])))
        self.method_combo = QComboBox()
        self.method_combo.addItems(["CASH", "BANK_TRANSFER", "QR_TRANSFER"])
        self.reference_edit = QLineEdit()
        self.note_edit = QLineEdit()

        form.addRow("Ngày thanh toán", self.date_edit)
        form.addRow("Số tiền", self.amount_spin)
        form.addRow("Phương thức", self.method_combo)
        form.addRow("Mã tham chiếu", self.reference_edit)
        form.addRow("Ghi chú", self.note_edit)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def save(self) -> None:
        self.commands.add_payment(
            invoice_id=int(self.invoice["id"]),
            payment_date=self.date_edit.date().toString("yyyy-MM-dd"),
            amount=self.amount_spin.value(),
            method=self.method_combo.currentText(),
            reference_no=self.reference_edit.text(),
            note=self.note_edit.text(),
        )


class InvoicesPage(QWidget):
    def __init__(self, queries: QueryService, commands: CommandService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries
        self.commands = commands
        self._invoice_rows: list[dict] = []

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("Hóa đơn và thanh toán", "Xem chi tiết hóa đơn, các dòng phí và ghi nhận thanh toán theo từng căn hộ."))

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tìm theo số hóa đơn, căn hộ hoặc kỳ thanh toán...")
        self.refresh_button = secondary_button("Làm mới")
        self.create_invoice_button = QPushButton("Phát hành hóa đơn")
        self.add_payment_button = QPushButton("Ghi nhận thanh toán")
        layout.addWidget(make_toolbar(self.search_edit, self.refresh_button, self.add_payment_button,self.create_invoice_button,))

        body = QHBoxLayout()
        body.setSpacing(16)
        self.invoice_table = QTableWidget()
        body.addWidget(self.invoice_table, 3)

        right = QVBoxLayout()
        right.setSpacing(10)
        lines_label = QLabel("Chi tiết hóa đơn")
        lines_label.setObjectName("PageSubtitle")
        self.lines_table = QTableWidget()
        payments_label = QLabel("Lịch sử thanh toán")
        payments_label.setObjectName("PageSubtitle")
        self.payments_table = QTableWidget()
        right.addWidget(lines_label)
        right.addWidget(self.lines_table, 2)
        right.addWidget(payments_label)
        right.addWidget(self.payments_table, 1)
        body.addLayout(right, 3)
        layout.addLayout(body, 1)

        self.search_edit.textChanged.connect(self.refresh)
        self.refresh_button.clicked.connect(self.refresh)
        self.invoice_table.itemSelectionChanged.connect(self.load_invoice_detail)
        self.add_payment_button.clicked.connect(self.open_add_payment_dialog)
        self.create_invoice_button.clicked.connect(self.open_create_invoice_dialog)

        self.refresh()

    def refresh(self) -> None:
        self._invoice_rows = self.queries.invoices(self.search_edit.text())
        rows = []
        for row in self._invoice_rows:
            rows.append(
                [
                    row["id"],
                    row["invoice_no"],
                    row["apartment_code"],
                    row["billing_month"],
                    row["due_date"],
                    format_money(row["total_amount"]),
                    format_money(row["paid_amount"]),
                    format_money(row["outstanding_amount"]),
                    row["status"],
                ]
            )
        set_table_data(
            self.invoice_table,
            ["ID", "MÃ HÓA ĐƠN", "CĂN", "KỲ", "HẠN TRẢ", "TỔNG TIỀN", "ĐÃ TRẢ", "CÒN NỢ", "TRẠNG THÁI"],
            rows,
        )
        if rows:
            self.invoice_table.selectRow(0)
        else:
            self.lines_table.clear()
            self.payments_table.clear()

    def current_invoice(self) -> dict | None:
        row = self.invoice_table.currentRow()
        if row < 0 or row >= len(self._invoice_rows):
            return None
        return self._invoice_rows[row]

    def load_invoice_detail(self) -> None:
        invoice = self.current_invoice()
        if not invoice:
            return
        lines = []
        for line in self.queries.invoice_lines(int(invoice["id"])):
            lines.append(
                [
                    line["item_code"],
                    line["description"],
                    f"{line['quantity']:.2f}",
                    line["unit"],
                    format_money(line["unit_price"]),
                    format_money(line["amount"]),
                ]
            )
        set_table_data(
            self.lines_table,
            ["MÃ PHÍ", "MÔ TẢ", "SỐ LƯỢNG", "ĐƠN VỊ", "ĐƠN GIÁ", "THÀNH TIỀN"],
            lines,
        )
        payment_rows = []
        for payment in self.queries.payments(int(invoice["id"])):
            payment_rows.append(
                [
                    payment["id"],
                    payment["payment_date"],
                    format_money(payment["amount"]),
                    payment["method"],
                    payment["reference_no"],
                    payment["note"],
                ]
            )
        set_table_data(
            self.payments_table,
            ["ID", "NGÀY", "SỐ TIỀN", "PHƯƠNG THỨC", "MÃ THAM CHIẾU", "GHI CHÚ"],
            payment_rows,
        )

    def open_add_payment_dialog(self) -> None:
        invoice = self.current_invoice()
        if not invoice:
            show_error(self, "Hãy chọn một hóa đơn trước.")
            return
        dialog = AddPaymentDialog(invoice, self.commands, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                dialog.save()
                show_info(self, "Đã ghi nhận thanh toán.")
                self.refresh()
            except Exception as exc:
                show_error(self, str(exc))
    
    def open_create_invoice_dialog(self) -> None:
        dialog = CreateInvoiceDialog(self.queries, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_data()
            try:
                # Gọi hàm create_invoice từ CommandService
                new_id = self.commands.create_invoice(
                    apartment_id=data["apartment_id"],
                    billing_month=data["month"],
                    bike_count=data["bike"],
                    car_count=data["car"],
                    other_fee=data["other"],
                    due_date=data["due_date"],
                )
                show_info(self, f"Đã phát hành hóa đơn mới (ID: {new_id}).")
                self.refresh()
            except Exception as e:
                show_error(self, f"Lỗi: {str(e)}")

class CreateInvoiceDialog(QDialog):
    def __init__(self, queries: QueryService, parent=None):
        super().__init__(parent)
        self.queries = queries
        self.setWindowTitle("Phát hành hóa đơn mới")
        self.setMinimumWidth(400)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.apt_combo = QComboBox()
        self.apt_map = {}
        for apt in self.queries.apartments(""):
            label = f"{apt['building_code']} - {apt['code']}"
            self.apt_map[label] = apt['id']
            self.apt_combo.addItem(label)

        self.month_edit = QLineEdit()
        self.month_edit.setPlaceholderText("YYYY-MM (Ví dụ: 2026-07)")
        self.month_edit.setText(QDate.currentDate().toString("yyyy-MM"))

        self.due_date_edit = QDateEdit()
        self.due_date_edit.setCalendarPopup(True)
        self.due_date_edit.setDate(QDate.currentDate().addDays(10))

        self.bike_spin = QSpinBox()
        self.bike_spin.setRange(0, 100)
        self.car_spin = QSpinBox()
        self.car_spin.setRange(0, 100)

        self.other_fee_spin = QDoubleSpinBox()
        self.other_fee_spin.setRange(0, 100_000_000)
        self.other_fee_spin.setDecimals(0)
        self.other_fee_spin.setSuffix(" VND")

        form.addRow("Chọn căn hộ:", self.apt_combo)
        form.addRow("Kỳ hóa đơn:", self.month_edit)
        form.addRow("Hạn thanh toán:", self.due_date_edit)
        form.addRow("Số xe máy:", self.bike_spin)
        form.addRow("Số ô tô:", self.car_spin)
        form.addRow("Phí khác:", self.other_fee_spin)
        
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_data(self):
        return {
            "apartment_id": int(self.apt_map[self.apt_combo.currentText()]),
            "month": self.month_edit.text().strip(),
            "due_date": self.due_date_edit.date().toString("yyyy-MM-dd"),
            "bike": self.bike_spin.value(),
            "car": self.car_spin.value(),
            "other": int(self.other_fee_spin.value()),
        }
