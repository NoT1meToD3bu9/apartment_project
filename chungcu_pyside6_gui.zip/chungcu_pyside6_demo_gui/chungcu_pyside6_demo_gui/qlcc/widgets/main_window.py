from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from qlcc.database import Database
from qlcc.services import CommandService, QueryService
from qlcc.styles import APP_STYLE
from qlcc.widgets.apartments_page import ApartmentsPage
from qlcc.widgets.dashboard_page import DashboardPage
from qlcc.widgets.invoices_page import InvoicesPage
from qlcc.widgets.meter_readings_page import MeterReadingsPage
from qlcc.widgets.residents_page import ResidentsPage


class MainWindow(QMainWindow):
    def __init__(self, db: Database, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Quản Lý Chung Cư")
        self.setStyleSheet(APP_STYLE)

        self.queries = QueryService(db)
        self.commands = CommandService(db)

        root = QWidget()
        root.setObjectName("Root")
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(18)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(270)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(22, 24, 22, 24)
        side_layout.setSpacing(0)

        brand = QLabel("Quản lý chung cư")
        brand.setObjectName("BrandTitle")
        side_layout.addWidget(brand)
        side_layout.addSpacing(18)

        self.menu = QListWidget()
        for text in [
            "Tổng quan",
            "Căn hộ",
            "Cư dân",
            "Chỉ số công tơ",
            "Hóa đơn & thanh toán",
        ]:
            QListWidgetItem(text, self.menu)
        self.menu.setCurrentRow(0)
        side_layout.addWidget(self.menu, 1)


        layout.addWidget(sidebar)

        content = QFrame()
        content.setObjectName("ContentSurface")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        self.pages = [
            DashboardPage(self.queries),
            ApartmentsPage(self.queries, self.commands),
            ResidentsPage(self.queries, self.commands),
            MeterReadingsPage(self.queries, self.commands),
            InvoicesPage(self.queries, self.commands),
        ]
        for page in self.pages:
            self.stack.addWidget(page)
        content_layout.addWidget(self.stack)
        layout.addWidget(content, 1)

        self.menu.currentRowChanged.connect(self.change_page)

    def change_page(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        page = self.pages[index]
        refresh = getattr(page, "refresh", None)
        if callable(refresh):
            refresh()
