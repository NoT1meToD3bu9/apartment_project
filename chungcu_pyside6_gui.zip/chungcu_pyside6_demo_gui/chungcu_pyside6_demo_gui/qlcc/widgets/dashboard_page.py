from __future__ import annotations

from PySide6.QtWidgets import QGridLayout, QLabel, QTableWidget, QVBoxLayout, QWidget

from qlcc.services import QueryService
from qlcc.utils import format_money
from qlcc.widgets.common import Card, PageHeader, set_table_data


class DashboardPage(QWidget):
    def __init__(self, queries: QueryService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.queries = queries

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("Tổng quan hệ thống", "Theo dõi nhanh số lượng căn hộ, cư dân và tình trạng công nợ."))

        card_grid = QGridLayout()
        card_grid.setHorizontalSpacing(14)
        card_grid.setVerticalSpacing(14)
        self.card_buildings = Card("TÒA NHÀ", "0")
        self.card_apartments = Card("CĂN HỘ", "0")
        self.card_residents = Card("CƯ DÂN", "0")
        self.card_open_invoices = Card("HÓA ĐƠN MỞ", "0")
        self.card_unpaid = Card("CÔNG NỢ", "0 VND")
        cards = [
            self.card_buildings,
            self.card_apartments,
            self.card_residents,
            self.card_open_invoices,
            self.card_unpaid,
        ]
        positions = [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1)]
        for card, (r, c) in zip(cards, positions):
            card_grid.addWidget(card, r, c)
        layout.addLayout(card_grid)

        recent_title = QLabel("Hóa đơn gần đây")
        recent_title.setObjectName("PageSubtitle")
        self.recent_table = QTableWidget()
        layout.addWidget(recent_title)
        layout.addWidget(self.recent_table, 1)

        self.refresh()

    def refresh(self) -> None:
        stats = self.queries.dashboard_stats()
        self.card_buildings.set_value(str(stats.buildings))
        self.card_apartments.set_value(str(stats.apartments))
        self.card_residents.set_value(str(stats.residents))
        self.card_open_invoices.set_value(str(stats.open_invoices))
        self.card_unpaid.set_value(format_money(stats.unpaid_amount))

        rows = []
        for row in self.queries.recent_invoices():
            rows.append(
                [
                    row["invoice_no"],
                    row["apartment_code"],
                    row["billing_month"],
                    format_money(row["total_amount"]),
                    format_money(row["paid_amount"]),
                    row["status"],
                ]
            )
        set_table_data(
            self.recent_table,
            ["MÃ HÓA ĐƠN", "CĂN HỘ", "KỲ", "TỔNG TIỀN", "ĐÃ TRẢ", "TRẠNG THÁI"],
            rows,
        )
