# QuanLyChungCu - PySide6 Demo

## Noi dung
- Dashboard tong quan
- Danh sach can ho + them can ho nhanh
- Danh sach cu dan + them cu dan nhanh
- Chi so cong to + them chi so moi
- Hoa don + chi tiet dong tien
- Ghi nhan thanh toan va tu dong cap nhat trang thai hoa don

## Chay thu
 Chay app o muc app.py, 3 noi dung tren tuy chon
```bash
python -m venv .venv 
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py   
```

## Ghi chu
- App dung file `chungcu.db` dat cung thu muc voi `app.py`.
