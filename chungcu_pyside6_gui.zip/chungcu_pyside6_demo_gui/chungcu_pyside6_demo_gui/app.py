from pathlib import Path
import sys

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from qlcc.database import Database
from qlcc.widgets.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Quản Lý Chung Cư")
    app.setFont(QFont("Segoe UI", 10))

    db_path = Path(__file__).resolve().parent / "chungcu.db"
    database = Database(db_path)

    window = MainWindow(database)
    window.resize(1320, 820)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
